import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useStore } from '../store/useStore';
import { Trophy, Medal, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../lib/errorHandling';

export default function Leaderboard() {
  const { user } = useStore();
  const [leaders, setLeaders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, 'users'),
      orderBy('total_score', 'desc'),
      limit(50)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc, index) => ({
        id: doc.id,
        rank: index + 1,
        // Mocking rank change for visual effect since we don't store historical rank
        rankChange: Math.floor(Math.random() * 3) - 1, 
        ...doc.data()
      }));
      setLeaders(data);
      setLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'users'));

    return () => unsubscribe();
  }, []);

  if (loading) {
    return <div className="animate-pulse space-y-4">
      <div className="h-10 bg-white/5 rounded w-1/4 mb-8"></div>
      {[...Array(5)].map((_, i) => <div key={i} className="h-20 bg-white/5 rounded-2xl"></div>)}
    </div>;
  }

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Medal className="text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.5)]" size={28} />;
    if (rank === 2) return <Medal className="text-gray-300 drop-shadow-[0_0_10px_rgba(209,213,219,0.5)]" size={28} />;
    if (rank === 3) return <Medal className="text-amber-600 drop-shadow-[0_0_10px_rgba(217,119,6,0.5)]" size={28} />;
    return <span className="text-xl font-bold text-gray-500 w-7 text-center">{rank}</span>;
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            <Trophy className="text-[#f59e0b]" /> Global Leaderboard
          </h1>
          <p className="text-gray-400 mt-1">Top 50 eco-warriors making a difference.</p>
        </div>
      </div>

      <div className="bg-[#0d2b1a] border border-white/5 rounded-3xl overflow-hidden">
        <div className="grid grid-cols-12 gap-4 p-4 border-b border-white/5 text-sm font-medium text-gray-400">
          <div className="col-span-2 text-center">Rank</div>
          <div className="col-span-6">Eco Warrior</div>
          <div className="col-span-2 text-center">Streak</div>
          <div className="col-span-2 text-right pr-4">Score</div>
        </div>

        <div className="divide-y divide-white/5">
          {leaders.map((leader, index) => {
            const isCurrentUser = leader.id === user?.uid;
            
            return (
              <motion.div 
                key={leader.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`grid grid-cols-12 gap-4 p-4 items-center transition-colors ${
                  isCurrentUser ? 'bg-[#00ff88]/10 border-l-4 border-[#00ff88]' : 'hover:bg-white/5'
                }`}
              >
                <div className="col-span-2 flex items-center justify-center gap-3">
                  <div className="flex flex-col items-center w-6">
                    {leader.rankChange > 0 ? <ArrowUp size={14} className="text-[#00ff88]" /> :
                     leader.rankChange < 0 ? <ArrowDown size={14} className="text-red-400" /> :
                     <Minus size={14} className="text-gray-600" />}
                  </div>
                  {getRankIcon(leader.rank)}
                </div>
                
                <div className="col-span-6 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00ff88] to-[#00cc6a] flex items-center justify-center text-black font-bold overflow-hidden">
                    {leader.avatar_url ? (
                      <img src={leader.avatar_url} alt={leader.display_name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      leader.display_name.charAt(0).toUpperCase()
                    )}
                  </div>
                  <div>
                    <div className="font-bold text-white flex items-center gap-2">
                      {leader.display_name}
                      {isCurrentUser && <span className="text-[10px] uppercase tracking-wider bg-[#00ff88] text-black px-2 py-0.5 rounded-full">You</span>}
                    </div>
                    <div className="text-xs text-[#00ff88] uppercase tracking-widest">{leader.level}</div>
                  </div>
                </div>

                <div className="col-span-2 flex items-center justify-center gap-1 font-medium text-[#f59e0b]">
                  🔥 {leader.current_streak}
                </div>

                <div className="col-span-2 text-right pr-4 font-bold text-white text-lg tracking-tighter">
                  {leader.total_score.toLocaleString()}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
