import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { collection, query, where, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useStore } from '../store/useStore';
import { Flame, Sparkles, TrendingDown, ArrowRight } from 'lucide-react';
import CountUp from 'react-countup';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { getAITip } from '../lib/gemini';
import { handleFirestoreError, OperationType } from '../lib/errorHandling';

export default function Dashboard() {
  const { user, profile } = useStore();
  const [recentLogs, setRecentLogs] = useState<any[]>([]);
  const [weeklyData, setWeeklyData] = useState<any[]>([]);
  const [aiTip, setAiTip] = useState<string>('');
  const [loadingTip, setLoadingTip] = useState(true);

  useEffect(() => {
    if (!user) return;

    // Fetch Recent Logs
    const logsQuery = query(
      collection(db, 'activity_logs'),
      where('user_id', '==', user.uid),
      orderBy('logged_at', 'desc'),
      limit(5)
    );

    const unsubscribeLogs = onSnapshot(logsQuery, (snapshot) => {
      const logs = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) }));
      setRecentLogs(logs);
      
      // Generate AI tip when logs change
      if (logs.length > 0 && profile) {
        setLoadingTip(true);
        // Simple heuristic for worst category (in a real app, calculate from daily_summaries)
        const worstCat = logs[0].category; 
        getAITip(logs, worstCat, profile.current_streak, profile.total_score)
          .then(tip => {
            setAiTip(tip);
            setLoadingTip(false);
          });
      } else {
        setLoadingTip(false);
      }
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'activity_logs'));

    // Fetch Weekly Summaries
    const today = new Date();
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const summaryQuery = query(
      collection(db, 'daily_summaries'),
      where('user_id', '==', user.uid),
      where('date', '>=', sevenDaysAgo.toISOString().split('T')[0]),
      orderBy('date', 'asc')
    );

    const unsubscribeSummary = onSnapshot(summaryQuery, (snapshot) => {
      const data = snapshot.docs.map(doc => doc.data());
      // Fill missing days
      const chartData = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const dateStr = d.toISOString().split('T')[0];
        const dayData = data.find(item => item.date === dateStr);
        chartData.push({
          name: d.toLocaleDateString('en-US', { weekday: 'short' }),
          carbon: dayData ? dayData.total_carbon_kg : 0
        });
      }
      setWeeklyData(chartData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'daily_summaries'));

    return () => {
      unsubscribeLogs();
      unsubscribeSummary();
    };
  }, [user, profile]);

  if (!profile) return null;

  const scorePercentage = Math.min(Math.max((profile.total_score / 2000) * 100, 0), 100);
  const circumference = 2 * Math.PI * 120;
  const strokeDashoffset = circumference - (scorePercentage / 100) * circumference;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome back, {profile.display_name.split(' ')[0]}</h1>
          <p className="text-gray-400 mt-1">Let's make a positive impact today.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="bg-[#0d2b1a] border border-[#f59e0b]/30 px-4 py-2 rounded-xl flex items-center gap-2">
            <Flame className="text-[#f59e0b]" size={20} />
            <span className="font-bold text-[#f59e0b]">{profile.current_streak} Day Streak</span>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Score Ring */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:col-span-1 bg-[#0d2b1a] border border-[#00ff88]/20 rounded-3xl p-8 flex flex-col items-center justify-center relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-[#00ff88]/5 to-transparent"></div>
          <h2 className="text-gray-400 font-medium mb-6 z-10">Your GreenScore</h2>
          
          <div className="relative w-64 h-64 flex items-center justify-center z-10">
            {/* SVG Ring */}
            <svg className="absolute inset-0 w-full h-full transform -rotate-90">
              <circle
                cx="128"
                cy="128"
                r="120"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                className="text-black/30"
              />
              <motion.circle
                cx="128"
                cy="128"
                r="120"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                strokeLinecap="round"
                className="text-[#00ff88] drop-shadow-[0_0_15px_rgba(0,255,136,0.5)]"
                strokeDasharray={circumference}
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset }}
                transition={{ duration: 2, ease: "easeOut" }}
              />
            </svg>
            
            <div className="text-center">
              <div className="text-6xl font-bold text-white tracking-tighter">
                <CountUp end={profile.total_score} duration={2.5} />
              </div>
              <div className="text-[#00ff88] font-medium mt-2 uppercase tracking-widest text-sm">
                {profile.level}
              </div>
            </div>
          </div>
        </motion.div>

        {/* AI Tip & Weekly Chart */}
        <div className="lg:col-span-2 space-y-8">
          {/* AI Tip Card */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-r from-[#0d2b1a] to-[#0a1a0f] border border-[#00ff88]/30 rounded-3xl p-6 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#00ff88]/10 rounded-full blur-3xl"></div>
            <div className="flex items-start gap-4 relative z-10">
              <div className="w-12 h-12 rounded-xl bg-[#00ff88]/20 flex items-center justify-center shrink-0">
                <Sparkles className="text-[#00ff88]" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                  AI Eco Tip
                </h3>
                {loadingTip ? (
                  <div className="animate-pulse flex flex-col gap-2">
                    <div className="h-4 bg-white/10 rounded w-3/4"></div>
                    <div className="h-4 bg-white/10 rounded w-1/2"></div>
                  </div>
                ) : (
                  <p className="text-gray-300 leading-relaxed">{aiTip}</p>
                )}
              </div>
            </div>
          </motion.div>

          {/* Weekly Chart */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-[#0d2b1a] border border-white/5 rounded-3xl p-6 h-64"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-white">Weekly Carbon Output</h3>
              <div className="text-sm text-gray-400 flex items-center gap-1">
                <TrendingDown size={16} className="text-[#00ff88]" />
                <span className="text-[#00ff88]">-12%</span> vs last week
              </div>
            </div>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyData}>
                <XAxis dataKey="name" stroke="#6b7280" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                  contentStyle={{ backgroundColor: '#0a1a0f', border: '1px solid rgba(0,255,136,0.2)', borderRadius: '12px' }}
                />
                <Bar dataKey="carbon" fill="#00ff88" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>
      </div>

      {/* Recent Activities */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-[#0d2b1a] border border-white/5 rounded-3xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-bold text-white text-xl">Recent Activities</h3>
          <button className="text-[#00ff88] text-sm font-medium flex items-center gap-1 hover:underline">
            View All <ArrowRight size={16} />
          </button>
        </div>
        
        <div className="space-y-4">
          {recentLogs.length === 0 ? (
            <div className="text-center py-8 text-gray-500">No activities logged yet. Start tracking!</div>
          ) : (
            recentLogs.map((log, i) => (
              <motion.div 
                key={log.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5 hover:border-white/10 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center text-2xl">
                    {log.category === 'transport' ? '🚗' : log.category === 'food' ? '🍔' : log.category === 'energy' ? '⚡' : '🌱'}
                  </div>
                  <div>
                    <div className="font-medium text-white">{log.activity_type}</div>
                    <div className="text-sm text-gray-400">{log.quantity} {log.unit} • {new Date(log.logged_at).toLocaleDateString()}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">{log.carbon_kg.toFixed(2)} kg</div>
                  <div className="text-xs text-gray-500">CO₂</div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </motion.div>
    </div>
  );
}
