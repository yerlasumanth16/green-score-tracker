import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Leaf, Activity, Trophy, Zap, ArrowRight } from 'lucide-react';

export default function Landing() {
  return (
    <div className="min-h-screen bg-[#0a1a0f] text-white overflow-hidden font-sans">
      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 bg-[#0a1a0f]/80 backdrop-blur-md border-b border-[#00ff88]/10">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#00ff88] flex items-center justify-center">
              <Leaf className="text-black" size={20} />
            </div>
            <span className="text-xl font-bold tracking-tight">GreenScore</span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/login" className="text-gray-300 hover:text-white font-medium transition-colors">Log in</Link>
            <Link to="/login" className="px-5 py-2.5 bg-[#00ff88] text-black font-bold rounded-full hover:shadow-[0_0_15px_rgba(0,255,136,0.5)] transition-all">
              Start Free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 px-6">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#00ff88]/20 rounded-full blur-[120px] -z-10"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#f59e0b]/10 rounded-full blur-[120px] -z-10"></div>

        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00ff88]/10 border border-[#00ff88]/20 text-[#00ff88] text-sm font-medium mb-6">
              <Zap size={16} />
              <span>The #1 Eco Impact Tracker</span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-bold leading-tight mb-6 tracking-tighter">
              Track Your Planet Impact, <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00ff88] to-[#00cc6a]">One Choice at a Time.</span>
            </h1>
            <p className="text-lg text-gray-400 mb-8 max-w-xl leading-relaxed">
              Log your daily activities, calculate your carbon footprint, and get AI-powered tips to live a greener life. Join thousands making a difference.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/login" className="px-8 py-4 bg-[#00ff88] text-black font-bold rounded-full hover:shadow-[0_0_25px_rgba(0,255,136,0.5)] transition-all flex items-center justify-center gap-2 text-lg">
                Start Tracking Free <ArrowRight size={20} />
              </Link>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-square rounded-full border border-[#00ff88]/20 flex items-center justify-center relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-[#00ff88]/10 to-transparent rounded-full animate-pulse"></div>
              <Leaf size={120} className="text-[#00ff88] drop-shadow-[0_0_30px_rgba(0,255,136,0.5)]" />
              
              {/* Floating elements */}
              <motion.div 
                animate={{ y: [-10, 10, -10] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                className="absolute top-10 right-10 bg-[#0d2b1a] border border-[#00ff88]/30 p-4 rounded-2xl backdrop-blur-md shadow-xl"
              >
                <div className="text-sm text-gray-400">Carbon Saved</div>
                <div className="text-2xl font-bold text-[#00ff88]">12.5 kg</div>
              </motion.div>

              <motion.div 
                animate={{ y: [10, -10, 10] }}
                transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
                className="absolute bottom-10 left-10 bg-[#0d2b1a] border border-[#f59e0b]/30 p-4 rounded-2xl backdrop-blur-md shadow-xl"
              >
                <div className="text-sm text-gray-400">Current Streak</div>
                <div className="text-2xl font-bold text-[#f59e0b] flex items-center gap-1">
                  14 Days <Zap size={20} />
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-[#0d2b1a]/50 border-y border-[#00ff88]/10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">How It Works</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Three simple steps to reduce your carbon footprint and build sustainable habits.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Activity, title: "1. Log Activities", desc: "Quickly log your meals, transport, and energy usage." },
              { icon: Zap, title: "2. Get Your Score", desc: "See your real-time carbon impact and GreenScore." },
              { icon: Trophy, title: "3. Improve & Compete", desc: "Get AI tips, earn badges, and climb the leaderboard." }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="bg-[#0a1a0f] border border-[#00ff88]/10 p-8 rounded-3xl hover:border-[#00ff88]/30 transition-colors"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#00ff88]/10 flex items-center justify-center mb-6">
                  <feature.icon className="text-[#00ff88]" size={28} />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-gray-400 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
