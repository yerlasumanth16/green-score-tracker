import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db, logOut } from '../lib/firebase';
import { useStore } from '../store/useStore';
import { User, Settings, LogOut, Trash2, Download, CheckCircle2 } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../lib/errorHandling';

export default function Profile() {
  const { user, profile, setProfile } = useStore();
  const [displayName, setDisplayName] = useState(profile?.display_name || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.display_name);
      setBio(profile.bio || '');
    }
  }, [profile]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        display_name: displayName,
        bio: bio,
        updated_at: new Date().toISOString()
      });
      
      setProfile({
        ...profile!,
        display_name: displayName,
        bio: bio
      });
      
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = async () => {
    await logOut();
  };

  const handleDeleteAccount = async () => {
    if (window.confirm("Are you sure you want to delete your account and all data? This cannot be undone.")) {
      if (!user) return;
      try {
        await deleteDoc(doc(db, 'users', user.uid));
        // In a real app, you'd also delete auth user and all sub-collections via Edge Function
        await logOut();
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}`);
      }
    }
  };

  if (!profile) return null;

  return (
    <div className="space-y-8 max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
          <User className="text-[#00ff88]" /> Profile & Settings
        </h1>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#0d2b1a] border border-white/5 rounded-3xl p-8"
      >
        <div className="flex items-center gap-6 mb-8">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#00ff88] to-[#00cc6a] flex items-center justify-center text-black font-bold text-4xl overflow-hidden shadow-[0_0_20px_rgba(0,255,136,0.3)]">
            {profile.avatar_url ? (
              <img src={profile.avatar_url} alt={profile.display_name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              profile.display_name.charAt(0).toUpperCase()
            )}
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">{profile.display_name}</h2>
            <div className="text-[#00ff88] font-medium uppercase tracking-widest text-sm mt-1">{profile.level} Member</div>
            <div className="text-gray-400 text-sm mt-1">Joined {new Date(profile.created_at).toLocaleDateString()}</div>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Display Name</label>
            <input 
              type="text" 
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#00ff88] transition-colors"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Bio</label>
            <textarea 
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#00ff88] transition-colors resize-none"
              placeholder="Tell the community about your eco journey..."
            />
          </div>

          <div className="pt-4 flex items-center gap-4">
            <button 
              onClick={handleSave}
              disabled={saving}
              className="px-6 py-3 bg-[#00ff88] text-black font-bold rounded-xl hover:bg-[#00cc6a] transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              {saving ? 'Saving...' : 'Save Changes'}
              {saved && <CheckCircle2 size={18} />}
            </button>
          </div>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-[#0d2b1a] border border-white/5 rounded-3xl p-8 space-y-6"
      >
        <h3 className="text-xl font-bold text-white flex items-center gap-2 mb-6">
          <Settings className="text-gray-400" /> Account Actions
        </h3>

        <div className="grid sm:grid-cols-2 gap-4">
          <button className="flex items-center justify-center gap-2 p-4 bg-black/30 border border-white/10 rounded-xl text-white hover:bg-white/5 transition-colors">
            <Download size={18} /> Export Data (CSV)
          </button>
          
          <button 
            onClick={handleLogout}
            className="flex items-center justify-center gap-2 p-4 bg-black/30 border border-white/10 rounded-xl text-white hover:bg-white/5 transition-colors"
          >
            <LogOut size={18} /> Sign Out
          </button>
        </div>

        <div className="pt-6 border-t border-white/5">
          <button 
            onClick={handleDeleteAccount}
            className="flex items-center gap-2 text-red-400 hover:text-red-300 transition-colors text-sm font-medium"
          >
            <Trash2 size={16} /> Delete Account Permanently
          </button>
        </div>
      </motion.div>
    </div>
  );
}
