import { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, where, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useStore } from '../store/useStore';
import { AreaChart, Area, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { getMonthlyPrediction, getPdfActionPlan } from '../lib/gemini';
import { handleFirestoreError, OperationType } from '../lib/errorHandling';
import { Download, TrendingDown, TrendingUp, Sparkles, Loader2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { PdfReportTemplate } from '../components/PdfReportTemplate';

const COLORS = ['#00ff88', '#f59e0b', '#3b82f6', '#a855f7', '#06b6d4'];

export default function Analytics() {
  const { user, profile } = useStore();
  const [monthlyData, setMonthlyData] = useState<any[]>([]);
  const [categoryData, setCategoryData] = useState<any[]>([]);
  const [topActivities, setTopActivities] = useState<any[]>([]);
  const [prediction, setPrediction] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [pdfProgress, setPdfProgress] = useState(0);
  const [aiActionPlan, setAiActionPlan] = useState<any[]>([]);
  const [badges, setBadges] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      try {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        const summaryQuery = query(
          collection(db, 'daily_summaries'),
          where('user_id', '==', user.uid),
          where('date', '>=', thirtyDaysAgo.toISOString().split('T')[0]),
          orderBy('date', 'asc')
        );

        const snapshot = await getDocs(summaryQuery);
        const data = snapshot.docs.map(doc => doc.data());

        // Process Area Chart Data
        const chartData = [];
        let totalTransport = 0, totalFood = 0, totalEnergy = 0, totalShopping = 0, totalWater = 0;

        for (let i = 29; i >= 0; i--) {
          const d = new Date();
          d.setDate(d.getDate() - i);
          const dateStr = d.toISOString().split('T')[0];
          const dayData = data.find(item => item.date === dateStr);
          
          if (dayData) {
            totalTransport += dayData.transport_kg || 0;
            totalFood += dayData.food_kg || 0;
            totalEnergy += dayData.energy_kg || 0;
            totalShopping += dayData.shopping_kg || 0;
            totalWater += dayData.water_kg || 0;
          }

          chartData.push({
            date: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            carbon: dayData ? dayData.total_carbon_kg : 0
          });
        }
        setMonthlyData(chartData);

        // Process Pie Chart Data
        setCategoryData([
          { name: 'Transport', value: totalTransport },
          { name: 'Food', value: totalFood },
          { name: 'Energy', value: totalEnergy },
          { name: 'Shopping', value: totalShopping },
          { name: 'Water', value: totalWater },
        ].filter(item => item.value > 0));

        // Get Logs for Top Activities and AI
        const logsQuery = query(
          collection(db, 'activity_logs'),
          where('user_id', '==', user.uid),
          orderBy('logged_at', 'desc')
        );
        const logsSnap = await getDocs(logsQuery);
        const logs = logsSnap.docs.map(doc => doc.data());
        
        setTopActivities([...logs].sort((a, b) => b.carbon_kg - a.carbon_kg));

        const pred = await getMonthlyPrediction(logs);
        setPrediction(pred);

        // Fetch Badges
        const badgesQuery = query(
          collection(db, 'badges'),
          where('user_id', '==', user.uid)
        );
        const badgesSnap = await getDocs(badgesQuery);
        setBadges(badgesSnap.docs.map(doc => doc.data()));

      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'analytics_data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const handleDownloadPdf = async () => {
    if (!user || !profile) return;
    
    setIsGeneratingPdf(true);
    setPdfProgress(10);

    try {
      // 1. Fetch AI Action Plan if not already fetched
      if (aiActionPlan.length === 0) {
        setPdfProgress(30);
        const plan = await getPdfActionPlan(topActivities, categoryData);
        setAiActionPlan(plan);
      }
      
      setPdfProgress(50);

      // 2. Wait a moment for the hidden template to render with new data
      await new Promise(resolve => setTimeout(resolve, 500));

      // 3. Generate PDF
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
        compress: true,
      });

      const template = document.getElementById('pdf-template');
      if (!template) throw new Error("PDF Template not found");

      const pages = template.querySelectorAll('.pdf-page');
      
      for (let i = 0; i < pages.length; i++) {
        setPdfProgress(50 + ((i + 1) / pages.length) * 40);
        const pageElement = pages[i] as HTMLElement;
        
        const canvas = await html2canvas(pageElement, {
          scale: 2,
          useCORS: true,
          backgroundColor: '#0a1a0f',
          logging: false,
          width: 794,
          height: 1123,
          scrollX: 0,
          scrollY: 0,
          windowWidth: 794,
          windowHeight: 1123,
        });

        if (i > 0) pdf.addPage();
        pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, 210, 297);
      }

      setPdfProgress(100);
      
      const monthYear = new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }).replace(' ', '_');
      pdf.save(`GreenScore_Report_${profile.display_name.replace(/\s+/g, '_')}_${monthYear}.pdf`);

    } catch (error) {
      console.error("Error generating PDF:", error);
      alert("Failed to generate PDF report. Please try again.");
    } finally {
      setTimeout(() => {
        setIsGeneratingPdf(false);
        setPdfProgress(0);
      }, 1000);
    }
  };

  const totalCarbonThisMonth = monthlyData.reduce((sum, d) => sum + d.carbon, 0);
  const dailyAverage = totalCarbonThisMonth / (monthlyData.length || 1);
  const greenDays = monthlyData.filter(d => d.carbon > 0 && d.carbon < 3).length; // Simplified logic

  if (loading) {
    return <div className="animate-pulse space-y-8">
      <div className="h-10 bg-white/5 rounded w-1/4"></div>
      <div className="h-64 bg-white/5 rounded-3xl"></div>
      <div className="grid grid-cols-2 gap-8"><div className="h-64 bg-white/5 rounded-3xl"></div><div className="h-64 bg-white/5 rounded-3xl"></div></div>
    </div>;
  }

  return (
    <div className="space-y-8 relative">
      {/* Hidden PDF Template */}
      {user && profile && (
        <PdfReportTemplate
          user={profile}
          monthlyData={monthlyData}
          categoryData={categoryData}
          topActivities={topActivities}
          aiProjection={prediction}
          aiActionPlan={aiActionPlan}
          badges={badges}
          totalCarbonThisMonth={totalCarbonThisMonth}
          dailyAverage={dailyAverage}
          streak={profile.current_streak || 0}
          greenDays={greenDays}
          dateRange={`Last 30 Days (${new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })})`}
        />
      )}

      {/* Loading Overlay */}
      <AnimatePresence>
        {isGeneratingPdf && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#0a1a0f]/90 backdrop-blur-md"
          >
            <Loader2 size={48} className="text-[#00ff88] animate-spin mb-6" />
            <h2 className="text-2xl font-bold text-white mb-2">Generating your eco report... 🌿</h2>
            <p className="text-gray-400 mb-8">Compiling data, charts, and AI insights</p>
            
            <div className="w-64 h-2 bg-black/50 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-[#00ff88]"
                initial={{ width: 0 }}
                animate={{ width: `${pdfProgress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
            <div className="mt-2 text-sm font-medium text-[#00ff88]">{Math.round(pdfProgress)}%</div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
        <button 
          onClick={handleDownloadPdf}
          disabled={isGeneratingPdf}
          className="flex items-center gap-2 px-4 py-2 bg-[#00ff88]/10 hover:bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/30 rounded-xl transition-colors text-sm font-bold shadow-[0_0_15px_rgba(0,255,136,0.2)]"
        >
          {isGeneratingPdf ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} 
          {isGeneratingPdf ? 'Generating...' : 'Download Report'}
        </button>
      </div>

      {/* Main Area Chart */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#0d2b1a] border border-white/5 rounded-3xl p-6 h-80"
      >
        <h3 className="font-bold text-white mb-6">30-Day Carbon Trend</h3>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={monthlyData}>
            <defs>
              <linearGradient id="colorCarbon" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00ff88" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#00ff88" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="date" stroke="#6b7280" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis stroke="#6b7280" fontSize={12} tickLine={false} axisLine={false} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#0a1a0f', border: '1px solid rgba(0,255,136,0.2)', borderRadius: '12px' }}
            />
            <Area type="monotone" dataKey="carbon" stroke="#00ff88" strokeWidth={3} fillOpacity={1} fill="url(#colorCarbon)" />
          </AreaChart>
        </ResponsiveContainer>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Category Breakdown */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#0d2b1a] border border-white/5 rounded-3xl p-6 flex flex-col"
        >
          <h3 className="font-bold text-white mb-6">Category Breakdown</h3>
          <div className="flex-1 flex items-center justify-center relative">
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#0a1a0f', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-gray-500">No data available</div>
            )}
            
            {/* Legend */}
            <div className="absolute bottom-0 w-full flex justify-center gap-4">
              {categoryData.map((entry, index) => (
                <div key={entry.name} className="flex items-center gap-2 text-sm text-gray-400">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                  {entry.name}
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* AI Prediction */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-br from-[#0d2b1a] to-[#0a1a0f] border border-[#f59e0b]/30 rounded-3xl p-6 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-48 h-48 bg-[#f59e0b]/10 rounded-full blur-3xl"></div>
          <div className="relative z-10 h-full flex flex-col">
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="text-[#f59e0b]" size={20} />
              <h3 className="font-bold text-white">AI Monthly Prediction</h3>
            </div>
            
            <div className="flex-1 flex flex-col justify-center">
              <div className="text-5xl font-bold text-white tracking-tighter mb-2">
                {prediction?.predicted_kg || 0} <span className="text-2xl text-gray-500 font-normal">kg CO₂</span>
              </div>
              <div className="text-[#f59e0b] font-medium mb-6">
                {prediction?.confidence_percentage || 0}% Confidence
              </div>
              
              <div className="bg-black/30 p-4 rounded-xl border border-white/5">
                <p className="text-gray-300 text-sm leading-relaxed">
                  {prediction?.reasoning || "Analyzing your data..."}
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
