import { GoogleGenAI } from "@google/genai";

// Initialize Gemini API
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const getAITip = async (history: any[], worstCategory: string, streak: number, score: number) => {
  try {
    const prompt = `
      You are an eco-coach for the GreenScore app.
      User Stats:
      - Worst Category: ${worstCategory || 'None'}
      - Current Streak: ${streak} days
      - GreenScore: ${score}
      - Recent Activities: ${JSON.stringify(history.slice(0, 5))}
      
      Provide exactly 1 specific, actionable, personalized tip in 2 sentences max to help them reduce their carbon footprint.
      Focus on their worst category if available. Be encouraging.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite-preview",
      contents: prompt,
    });

    return response.text || "Try walking or biking for short trips today to reduce your transport emissions!";
  } catch (error) {
    console.error("Error fetching AI tip:", error);
    return "Consider eating one plant-based meal today to significantly lower your food carbon footprint.";
  }
};

export const getMonthlyPrediction = async (logs: any[]) => {
  try {
    const prompt = `
      Based on these recent activity logs: ${JSON.stringify(logs.slice(0, 20))}
      Predict the total carbon footprint (in kg CO2) for the current month.
      Return ONLY a JSON object with this exact structure, no markdown formatting:
      {
        "predicted_kg": number,
        "confidence_percentage": number,
        "reasoning": "1 sentence explanation"
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Error fetching prediction:", error);
    return { predicted_kg: 150, confidence_percentage: 75, reasoning: "Based on average user data." };
  }
};

export const getPdfActionPlan = async (logs: any[], categoryData: any[]) => {
  try {
    const prompt = `
      You are an expert environmental scientist and AI eco-coach.
      Based on the user's recent activity logs and category breakdown, generate a personalized 30-day improvement plan.
      
      Category Breakdown: ${JSON.stringify(categoryData)}
      Recent Logs: ${JSON.stringify(logs.slice(0, 30))}
      
      Generate exactly 5 actionable steps.
      Return ONLY a JSON array of objects with this exact structure, no markdown formatting:
      [
        {
          "title": "string (Action title)",
          "description": "string (2 lines max description)",
          "estimated_saving_kg": number (Estimated kg CO2 saved per month),
          "category": "string (e.g., Transport, Food, Energy)",
          "difficulty": "number (1=easy/green, 3=medium/amber, 5=hard/red)"
        }
      ]
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Error fetching PDF action plan:", error);
    return [
      { title: "Meatless Mondays", description: "Replace meat with plant-based alternatives once a week.", estimated_saving_kg: 12, category: "Food", difficulty: 1 },
      { title: "Optimize AC Usage", description: "Increase your AC temperature by 2 degrees.", estimated_saving_kg: 15, category: "Energy", difficulty: 2 },
      { title: "Walk Short Distances", description: "Walk for trips under 2km instead of driving.", estimated_saving_kg: 8, category: "Transport", difficulty: 3 },
      { title: "Reduce Shower Time", description: "Cut your shower time by 2 minutes.", estimated_saving_kg: 5, category: "Water", difficulty: 1 },
      { title: "Buy Second-hand", description: "Purchase one second-hand item instead of new.", estimated_saving_kg: 20, category: "Shopping", difficulty: 4 }
    ];
  }
};
