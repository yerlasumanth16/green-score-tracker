import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[#0a1a0f] text-white p-4">
          <div className="bg-[#0d2b1a] p-8 rounded-2xl border border-[#00ff88]/20 max-w-lg w-full">
            <h2 className="text-2xl font-bold text-red-400 mb-4">Something went wrong</h2>
            <div className="bg-black/30 p-4 rounded-lg overflow-auto max-h-64 text-sm font-mono text-gray-300">
              {this.state.error?.message}
            </div>
            <button
              className="mt-6 w-full py-3 bg-[#00ff88] text-black font-bold rounded-xl hover:bg-[#00cc6a] transition-colors"
              onClick={() => window.location.reload()}
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }

    return (this as any).props.children;
  }
}
