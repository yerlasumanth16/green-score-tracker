import { Outlet, Link, useLocation } from 'react-router-dom';
import { Home, BarChart2, Trophy, User, Plus } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useState } from 'react';
import LogActivityModal from './LogActivityModal';
import Chatbot from './Chatbot';

export default function Layout() {
  const location = useLocation();
  const { profile } = useStore();
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);

  const navItems = [
    { path: '/dashboard', icon: Home, label: 'Home' },
    { path: '/analytics', icon: BarChart2, label: 'Analytics' },
    { path: '/leaderboard', icon: Trophy, label: 'Leaderboard' },
    { path: '/profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="min-h-screen bg-[#0a1a0f] text-white flex flex-col md:flex-row font-sans">
      {/* Sidebar (Desktop) */}
      <aside className="hidden md:flex flex-col w-64 bg-[#0d2b1a] border-r border-[#00ff88]/20 p-6">
        <div className="flex items-center gap-3 mb-12">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#00ff88] to-[#00cc6a] flex items-center justify-center text-black font-bold text-xl">
            G
          </div>
          <span className="text-xl font-bold tracking-tight">GreenScore</span>
        </div>

        <nav className="flex-1 space-y-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  isActive 
                    ? 'bg-[#00ff88]/10 text-[#00ff88] border border-[#00ff88]/20' 
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon size={20} />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <button 
          onClick={() => setIsLogModalOpen(true)}
          className="mt-8 w-full py-4 bg-gradient-to-r from-[#00ff88] to-[#00cc6a] text-black font-bold rounded-xl flex items-center justify-center gap-2 hover:shadow-[0_0_20px_rgba(0,255,136,0.4)] transition-all transform hover:scale-105"
        >
          <Plus size={20} />
          Log Activity
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pb-24 md:pb-0 relative">
        <div className="max-w-5xl mx-auto p-4 md:p-8">
          <Outlet />
        </div>
      </main>

      {/* Bottom Nav (Mobile) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-[#0d2b1a]/90 backdrop-blur-lg border-t border-[#00ff88]/20 flex items-center justify-around p-4 z-40">
        {navItems.slice(0, 2).map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <Link key={item.path} to={item.path} className={`p-2 ${isActive ? 'text-[#00ff88]' : 'text-gray-400'}`}>
              <Icon size={24} />
            </Link>
          );
        })}
        
        <button 
          onClick={() => setIsLogModalOpen(true)}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-[#00ff88] to-[#00cc6a] text-black flex items-center justify-center -mt-8 shadow-[0_0_20px_rgba(0,255,136,0.4)] relative z-50"
        >
          <Plus size={28} />
        </button>

        {navItems.slice(2, 4).map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <Link key={item.path} to={item.path} className={`p-2 ${isActive ? 'text-[#00ff88]' : 'text-gray-400'}`}>
              <Icon size={24} />
            </Link>
          );
        })}
      </nav>

      {isLogModalOpen && <LogActivityModal onClose={() => setIsLogModalOpen(false)} />}
      <Chatbot />
    </div>
  );
}
