import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Car, Utensils, Zap, ShoppingBag, Droplets, ArrowRight, CheckCircle2 } from 'lucide-react';
import { collection, addDoc, doc, updateDoc, increment, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useStore } from '../store/useStore';
import { handleFirestoreError, OperationType } from '../lib/errorHandling';
import Confetti from 'react-confetti';

const CATEGORIES = [
  { id: 'transport', name: 'Transport', icon: Car, color: 'text-blue-400', bg: 'bg-blue-400/10' },
  { id: 'food', name: 'Food', icon: Utensils, color: 'text-orange-400', bg: 'bg-orange-400/10' },
  { id: 'energy', name: 'Energy', icon: Zap, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
  { id: 'shopping', name: 'Shopping', icon: ShoppingBag, color: 'text-purple-400', bg: 'bg-purple-400/10' },
  { id: 'water', name: 'Water', icon: Droplets, color: 'text-cyan-400', bg: 'bg-cyan-400/10' },
];

const ACTIVITIES: Record<string, { id: string, name: string, factor: number, unit: string }[]> = {
  transport: [
    { id: 'car_petrol', name: 'Car (Petrol)', factor: 0.21, unit: 'km' },
    { id: 'car_diesel', name: 'Car (Diesel)', factor: 0.17, unit: 'km' },
    { id: 'car_ev', name: 'Car (Electric)', factor: 0.05, unit: 'km' },
    { id: 'bus', name: 'Bus', factor: 0.089, unit: 'km' },
    { id: 'train', name: 'Train', factor: 0.041, unit: 'km' },
    { id: 'flight_short', name: 'Flight (Short)', factor: 0.255, unit: 'km' },
    { id: 'bike', name: 'Bike', factor: 0, unit: 'km' },
    { id: 'walk', name: 'Walking', factor: 0, unit: 'km' },
  ],
  food: [
    { id: 'meat_red', name: 'Red Meat Meal', factor: 6.61, unit: 'meals' },
    { id: 'meat_chicken', name: 'Chicken Meal', factor: 1.92, unit: 'meals' },
    { id: 'veg', name: 'Vegetarian Meal', factor: 0.87, unit: 'meals' },
    { id: 'vegan', name: 'Vegan Meal', factor: 0.56, unit: 'meals' },
  ],
  energy: [
    { id: 'ac', name: 'AC Usage', factor: 1.2, unit: 'hours' },
    { id: 'washing', name: 'Washing Machine', factor: 0.6, unit: 'loads' },
  ],
  shopping: [
    { id: 'clothes', name: 'New Clothing', factor: 15.0, unit: 'items' },
    { id: 'electronics', name: 'Electronics', factor: 50.0, unit: 'items' },
  ],
  water: [
    { id: 'shower', name: 'Shower', factor: 0.14, unit: 'minutes' },
    { id: 'bath', name: 'Bath', factor: 2.5, unit: 'baths' },
  ]
};

export default function LogActivityModal({ onClose }: { onClose: () => void }) {
  const { user, profile, setProfile } = useStore();
  const [step, setStep] = useState(1);
  const [category, setCategory] = useState('');
  const [activity, setActivity] = useState('');
  const [quantity, setQuantity] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const selectedActivity = category && activity ? ACTIVITIES[category].find(a => a.id === activity) : null;

  const [isGreenActivity, setIsGreenActivity] = useState(false);

  const handleSave = async () => {
    if (!user || !profile || !selectedActivity) return;
    
    setLoading(true);
    try {
      const carbonKg = selectedActivity.factor * Number(quantity);
      const isGreen = carbonKg < 2; // Arbitrary threshold for a "green" activity
      setIsGreenActivity(isGreen);
      
      // 1. Save Activity Log
      await addDoc(collection(db, 'activity_logs'), {
        user_id: user.uid,
        category,
        activity_type: selectedActivity.name,
        quantity: Number(quantity),
        unit: selectedActivity.unit,
        carbon_kg: carbonKg,
        logged_at: new Date().toISOString(),
      });

      // 2. Update Daily Summary
      const today = new Date().toISOString().split('T')[0];
      const summaryRef = doc(db, 'daily_summaries', `${user.uid}_${today}`);
      const summarySnap = await getDoc(summaryRef);
      
      if (summarySnap.exists()) {
        await updateDoc(summaryRef, {
          total_carbon_kg: increment(carbonKg),
          [`${category}_kg`]: increment(carbonKg),
        });
      } else {
        await setDoc(summaryRef, {
          user_id: user.uid,
          date: today,
          total_carbon_kg: carbonKg,
          transport_kg: category === 'transport' ? carbonKg : 0,
          food_kg: category === 'food' ? carbonKg : 0,
          energy_kg: category === 'energy' ? carbonKg : 0,
          is_green_day: true, // Will be evaluated later
          score_earned: 0
        });
      }

      // 3. Update User Profile Score
      // Base calculation: deduct points for carbon, add bonus for 0 carbon
      let scoreChange = isGreen ? 10 : -Math.round(carbonKg * 2);
      
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        total_score: increment(scoreChange),
      });

      // Update local state
      setProfile({
        ...profile,
        total_score: profile.total_score + scoreChange
      });

      setSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2000);

    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'activity_logs');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-[#0d2b1a] border border-[#00ff88]/20 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl"
      >
        <div className="p-6 border-b border-[#00ff88]/10 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-white">Log Activity</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="p-6 min-h-[300px]">
          <AnimatePresence mode="wait">
            {success ? (
              <motion.div 
                key="success"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center h-full py-12 text-center relative"
              >
                {isGreenActivity && <Confetti width={500} height={400} recycle={false} numberOfPieces={200} gravity={0.3} />}
                <div className="w-20 h-20 bg-[#00ff88]/20 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle2 size={40} className="text-[#00ff88]" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Activity Logged!</h3>
                <p className="text-gray-400">Your GreenScore has been updated.</p>
              </motion.div>
            ) : step === 1 ? (
              <motion.div key="step1" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
                <h3 className="text-lg font-medium text-gray-300 mb-4">Select Category</h3>
                <div className="grid grid-cols-2 gap-3">
                  {CATEGORIES.map(cat => {
                    const Icon = cat.icon;
                    return (
                      <button
                        key={cat.id}
                        onClick={() => { setCategory(cat.id); setStep(2); }}
                        className={`p-4 rounded-2xl border flex flex-col items-center gap-3 transition-all hover:scale-105 ${
                          category === cat.id ? 'border-[#00ff88] bg-[#00ff88]/10' : 'border-white/10 bg-black/20 hover:border-white/30'
                        }`}
                      >
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${cat.bg}`}>
                          <Icon className={cat.color} size={24} />
                        </div>
                        <span className="font-medium text-white">{cat.name}</span>
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            ) : step === 2 ? (
              <motion.div key="step2" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
                <button onClick={() => setStep(1)} className="text-[#00ff88] text-sm font-medium mb-4 flex items-center gap-1">
                  ← Back to Categories
                </button>
                <h3 className="text-lg font-medium text-gray-300 mb-4">Select Activity</h3>
                <div className="space-y-2">
                  {ACTIVITIES[category]?.map(act => (
                    <button
                      key={act.id}
                      onClick={() => { setActivity(act.id); setStep(3); }}
                      className="w-full p-4 rounded-xl border border-white/10 bg-black/20 hover:border-[#00ff88]/50 hover:bg-[#00ff88]/5 transition-all text-left flex items-center justify-between"
                    >
                      <span className="text-white font-medium">{act.name}</span>
                      <ArrowRight size={18} className="text-gray-500" />
                    </button>
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div key="step3" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
                <button onClick={() => setStep(2)} className="text-[#00ff88] text-sm font-medium mb-4 flex items-center gap-1">
                  ← Back to Activities
                </button>
                <h3 className="text-lg font-medium text-gray-300 mb-6">Enter Details</h3>
                
                <div className="bg-black/30 p-6 rounded-2xl border border-white/5 mb-6">
                  <div className="text-sm text-gray-400 mb-2">{selectedActivity?.name}</div>
                  <div className="flex items-end gap-4">
                    <input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      placeholder="0"
                      className="bg-transparent text-5xl font-bold text-white w-32 outline-none border-b-2 border-gray-700 focus:border-[#00ff88] transition-colors pb-2"
                      autoFocus
                    />
                    <span className="text-xl text-gray-500 pb-3">{selectedActivity?.unit}</span>
                  </div>
                </div>

                {quantity && Number(quantity) > 0 && (
                  <div className="flex justify-between items-center p-4 bg-[#00ff88]/10 border border-[#00ff88]/20 rounded-xl mb-8">
                    <span className="text-[#00ff88] font-medium">Estimated Impact</span>
                    <span className="text-white font-bold text-xl">
                      {(selectedActivity!.factor * Number(quantity)).toFixed(2)} kg CO₂
                    </span>
                  </div>
                )}

                <button
                  onClick={handleSave}
                  disabled={!quantity || Number(quantity) <= 0 || loading}
                  className="w-full py-4 bg-[#00ff88] text-black font-bold rounded-xl hover:bg-[#00cc6a] transition-colors disabled:opacity-50 flex items-center justify-center"
                >
                  {loading ? 'Saving...' : 'Log Activity'}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
