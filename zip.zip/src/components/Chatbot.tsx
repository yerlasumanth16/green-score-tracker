import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Bot, User } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { useStore } from '../store/useStore';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function Chatbot() {
  const { profile } = useStore();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([
    { role: 'model', text: "Hi! I'm your GreenScore assistant. Ask me how your score is calculated or for eco tips!" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !profile) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const prompt = `
        You are the GreenScore AI Assistant.
        The user's current stats:
        - GreenScore: ${profile.total_score}
        - Current Streak: ${profile.current_streak}
        - Level: ${profile.level}
        
        Rules for GreenScore:
        - Start at 1000 points.
        - Each kg of CO2 logged deducts points (approx 2 points per kg).
        - Green activities (walking, vegan meal) add 10 bonus points.
        - Streak multiplier: score * (1 + streak * 0.05).
        
        User message: "${userMsg}"
        
        Respond concisely, friendly, and directly address their stats if relevant.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite-preview",
        contents: prompt,
      });

      setMessages(prev => [...prev, { role: 'model', text: response.text || "I'm not sure how to answer that right now." }]);
    } catch (error) {
      console.error("Chat error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, I'm having trouble connecting right now." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-24 right-4 md:bottom-8 md:right-8 w-80 sm:w-96 bg-[#0d2b1a] border border-[#00ff88]/30 rounded-2xl shadow-2xl overflow-hidden z-50 flex flex-col h-[500px] max-h-[80vh]"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-[#00ff88] to-[#00cc6a] p-4 flex items-center justify-between">
              <div className="flex items-center gap-2 text-black font-bold">
                <Bot size={20} />
                <span>Eco Assistant</span>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-black/70 hover:text-black transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#0a1a0f]">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl p-3 text-sm ${
                    msg.role === 'user' 
                      ? 'bg-[#00ff88]/20 text-white border border-[#00ff88]/30 rounded-tr-sm' 
                      : 'bg-white/10 text-gray-200 border border-white/5 rounded-tl-sm'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-white/10 text-gray-200 border border-white/5 rounded-2xl rounded-tl-sm p-3 text-sm flex gap-1">
                    <span className="animate-bounce">.</span><span className="animate-bounce" style={{ animationDelay: '0.2s' }}>.</span><span className="animate-bounce" style={{ animationDelay: '0.4s' }}>.</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-3 bg-[#0d2b1a] border-t border-white/10">
              <div className="flex items-center gap-2 bg-black/30 border border-white/10 rounded-xl p-1">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask about your score..."
                  className="flex-1 bg-transparent text-white text-sm px-3 py-2 outline-none"
                />
                <button 
                  onClick={handleSend}
                  disabled={!input.trim() || loading}
                  className="p-2 bg-[#00ff88] text-black rounded-lg hover:bg-[#00cc6a] transition-colors disabled:opacity-50"
                >
                  <Send size={16} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-24 right-4 md:bottom-8 md:right-8 w-14 h-14 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(0,255,136,0.3)] transition-all z-40 ${
          isOpen ? 'bg-white/10 text-white scale-0' : 'bg-[#00ff88] text-black scale-100 hover:scale-110'
        }`}
      >
        <MessageSquare size={24} />
      </button>
    </>
  );
}
