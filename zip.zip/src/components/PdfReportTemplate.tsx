import React, { useEffect, useRef } from 'react';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend, Filler } from 'chart.js';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import { Leaf, Flame, Calendar, Trophy, Car, Utensils, Zap, ShoppingBag, Droplets, Plane, Battery } from 'lucide-react';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend, Filler);

interface PdfReportTemplateProps {
  user: any;
  monthlyData: any[];
  categoryData: any[];
  topActivities: any[];
  aiProjection: any;
  aiActionPlan: any[];
  badges: any[];
  totalCarbonThisMonth: number;
  dailyAverage: number;
  streak: number;
  greenDays: number;
  dateRange: string;
}

export const PdfReportTemplate: React.FC<PdfReportTemplateProps> = ({
  user,
  monthlyData,
  categoryData,
  topActivities,
  aiProjection,
  aiActionPlan,
  badges,
  totalCarbonThisMonth,
  dailyAverage,
  streak,
  greenDays,
  dateRange
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Colors
  const colors = {
    bg: '#0a1a0f',
    card: '#0d2b1a',
    primary: '#00ff88',
    secondary: '#f59e0b',
    danger: '#ef4444',
    text: '#ffffff',
    muted: '#6b7280',
    border: 'rgba(0,255,136,0.2)'
  };

  const categoryColors: Record<string, string> = {
    Transport: '#3b82f6',
    Food: '#f59e0b',
    Energy: '#ef4444',
    Shopping: '#8b5cf6',
    Water: '#06b6d4'
  };

  const getCategoryIcon = (cat: string) => {
    switch (cat.toLowerCase()) {
      case 'transport': return <Car size={20} color={categoryColors.Transport} />;
      case 'food': return <Utensils size={20} color={categoryColors.Food} />;
      case 'energy': return <Zap size={20} color={categoryColors.Energy} />;
      case 'shopping': return <ShoppingBag size={20} color={categoryColors.Shopping} />;
      case 'water': return <Droplets size={20} color={categoryColors.Water} />;
      default: return <Leaf size={20} color={colors.primary} />;
    }
  };

  const worstCategory = categoryData.length > 0 ? categoryData.reduce((prev, current) => (prev.value > current.value) ? prev : current) : { name: 'None', value: 0 };
  const bestCategory = categoryData.length > 0 ? categoryData.reduce((prev, current) => (prev.value < current.value) ? prev : current) : { name: 'None', value: 0 };

  // Chart Options
  const commonChartOptions = {
    animation: false as const,
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: { enabled: false } },
    scales: {
      x: { grid: { display: false }, ticks: { color: colors.muted, font: { family: 'Inter', size: 10 } } },
      y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: colors.muted, font: { family: 'Inter', size: 10 } } }
    }
  };

  // Page 2: Daily Carbon Timeline Data
  const dailyTimelineData = {
    labels: monthlyData.map(d => d.date),
    datasets: [{
      label: 'Carbon (kg)',
      data: monthlyData.map(d => d.carbon),
      backgroundColor: monthlyData.map(d => d.carbon < 3 ? colors.primary : d.carbon < 5 ? colors.secondary : colors.danger),
      borderRadius: 4
    }]
  };

  // Page 2: Category Donut Data
  const donutData = {
    labels: categoryData.map(c => c.name),
    datasets: [{
      data: categoryData.map(c => c.value),
      backgroundColor: categoryData.map(c => categoryColors[c.name] || colors.primary),
      borderWidth: 0,
      cutout: '70%'
    }]
  };

  // Page 2: Weekly Trend Data (Mocked for simplicity, assuming monthlyData is 30 days)
  const weeklyTrendData = {
    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
    datasets: [
      {
        label: 'Your Carbon',
        data: [
          monthlyData.slice(0, 7).reduce((sum, d) => sum + d.carbon, 0),
          monthlyData.slice(7, 14).reduce((sum, d) => sum + d.carbon, 0),
          monthlyData.slice(14, 21).reduce((sum, d) => sum + d.carbon, 0),
          monthlyData.slice(21, 28).reduce((sum, d) => sum + d.carbon, 0)
        ],
        borderColor: colors.primary,
        backgroundColor: 'rgba(0,255,136,0.1)',
        fill: true,
        tension: 0.4,
        pointBackgroundColor: colors.primary,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 4
      },
      {
        label: 'Global Avg',
        data: [35, 35, 35, 35],
        borderColor: colors.secondary,
        borderDash: [5, 5],
        fill: false,
        tension: 0.4,
        pointRadius: 0
      }
    ]
  };

  // Page 4: AI Projection Data
  const projectionData = {
    labels: Array.from({ length: 31 }, (_, i) => i + 1),
    datasets: [
      {
        label: 'Actual',
        data: monthlyData.map(d => d.carbon),
        borderColor: colors.primary,
        tension: 0.4,
        pointRadius: 0
      },
      {
        label: 'Projection',
        data: [...Array(monthlyData.length).fill(null), ...Array(31 - monthlyData.length).fill(aiProjection?.predicted_kg / 31 || 5)],
        borderColor: colors.secondary,
        borderDash: [5, 5],
        backgroundColor: 'rgba(245,158,11,0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 0
      }
    ]
  };

  const PageHeader = () => (
    <div style={{ background: 'linear-gradient(135deg, #0d2b1a, #1a3d20)', borderBottom: `2px solid ${colors.primary}` }} className="h-[120px] px-8 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-[#00ff88]/20 rounded-xl flex items-center justify-center">
          <Leaf size={28} color={colors.primary} />
        </div>
        <span style={{ fontFamily: 'Syne', fontSize: '28px', fontWeight: 'bold', color: colors.text }}>GreenScore</span>
      </div>
      <div style={{ fontFamily: 'Inter', fontSize: '14px', fontWeight: 600, color: colors.muted, letterSpacing: '2px' }}>
        ECO IMPACT ANALYTICS REPORT
      </div>
      <div className="flex items-center gap-4 text-right">
        <div>
          <div style={{ fontFamily: 'Inter', fontSize: '16px', fontWeight: 600, color: colors.text }}>{user?.display_name || 'Eco Warrior'}</div>
          <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.muted }}>{dateRange}</div>
        </div>
        {user?.avatar_url ? (
          <img src={user.avatar_url} alt="Avatar" className="w-10 h-10 rounded-full border-2 border-[#00ff88]" crossOrigin="anonymous" />
        ) : (
          <div className="w-10 h-10 rounded-full bg-[#00ff88]/20 border-2 border-[#00ff88] flex items-center justify-center text-[#00ff88] font-bold">
            {user?.display_name?.charAt(0) || 'E'}
          </div>
        )}
      </div>
    </div>
  );

  const PageFooter = ({ pageNum }: { pageNum: number }) => (
    <div className="absolute bottom-0 left-0 w-full h-[60px] px-8 flex items-center justify-between border-t border-white/5" style={{ background: colors.bg }}>
      <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.muted }}>Generated by GreenScore • greenscore.app</div>
      <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.muted }}>Page {pageNum} / 4</div>
    </div>
  );

  const pageStyle = {
    width: '794px',
    height: '1123px',
    backgroundColor: colors.bg,
    position: 'relative' as const,
    overflow: 'hidden',
    boxSizing: 'border-box' as const,
    pageBreakAfter: 'always' as const
  };

  const cardStyle = {
    backgroundColor: colors.card,
    border: `1px solid ${colors.border}`,
    borderRadius: '16px',
    padding: '20px'
  };

  return (
    <div id="pdf-template" ref={containerRef} style={{ position: 'fixed', left: '-9999px', top: 0, width: '794px', backgroundColor: colors.bg }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Syne:wght@700&display=swap');
      `}</style>

      {/* PAGE 1: EXECUTIVE SUMMARY */}
      <div className="pdf-page" style={pageStyle}>
        <PageHeader />
        <div className="p-6">
          {/* Hero Score Section */}
          <div className="flex flex-col items-center justify-center h-[240px] mb-8 relative">
             <div className="relative w-48 h-48 flex items-center justify-center">
                <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                  <circle cx="96" cy="96" r="88" stroke="rgba(255,255,255,0.1)" strokeWidth="12" fill="none" />
                  <circle cx="96" cy="96" r="88" stroke="url(#scoreGradient)" strokeWidth="12" fill="none" strokeDasharray="552" strokeDashoffset={552 - (552 * Math.min(user?.total_score || 0, 1000) / 1000)} strokeLinecap="round" />
                  <defs>
                    <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#00ff88" />
                      <stop offset="100%" stopColor="#00cc6a" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="text-center">
                  <div style={{ fontFamily: 'Syne', fontSize: '48px', fontWeight: 'bold', color: colors.primary, lineHeight: 1 }}>{user?.total_score || 0}</div>
                  <div style={{ fontFamily: 'Inter', fontSize: '14px', color: colors.muted }}>/ 1000</div>
                </div>
             </div>
             <div className="mt-4 px-4 py-1 rounded-full text-sm font-bold" style={{ backgroundColor: 'rgba(245,158,11,0.2)', color: colors.secondary, border: `1px solid ${colors.secondary}` }}>
                {user?.level?.toUpperCase() || 'BRONZE'} LEVEL
             </div>
          </div>

          {/* Stat Pills */}
          <div className="flex justify-center gap-4 mb-8">
            <div style={cardStyle} className="flex items-center gap-3 py-3 px-6 rounded-full">
              <span className="text-xl">🌍</span>
              <span style={{ fontFamily: 'Inter', fontSize: '14px', color: colors.text }}>Total CO₂: <strong style={{ color: colors.primary }}>{totalCarbonThisMonth.toFixed(1)} kg</strong></span>
            </div>
            <div style={cardStyle} className="flex items-center gap-3 py-3 px-6 rounded-full">
              <span className="text-xl">🔥</span>
              <span style={{ fontFamily: 'Inter', fontSize: '14px', color: colors.text }}>Current Streak: <strong style={{ color: colors.secondary }}>{streak} days</strong></span>
            </div>
            <div style={cardStyle} className="flex items-center gap-3 py-3 px-6 rounded-full">
              <span className="text-xl">📅</span>
              <span style={{ fontFamily: 'Inter', fontSize: '14px', color: colors.text }}>Green Days: <strong style={{ color: colors.primary }}>{greenDays} / 30</strong></span>
            </div>
          </div>

          {/* KPI Cards Grid */}
          <div className="grid grid-cols-2 gap-6">
            {/* Card 1 */}
            <div style={cardStyle}>
              <div style={{ fontFamily: 'Inter', fontSize: '14px', color: colors.muted, marginBottom: '8px' }}>Total CO₂ Emitted</div>
              <div style={{ fontFamily: 'Syne', fontSize: '40px', fontWeight: 'bold', color: colors.primary, marginBottom: '16px' }}>{totalCarbonThisMonth.toFixed(1)} kg</div>
              <div className="h-16 mb-4">
                <Bar data={{
                  labels: monthlyData.slice(-7).map(d => d.date),
                  datasets: [{ data: monthlyData.slice(-7).map(d => d.carbon), backgroundColor: colors.primary, borderRadius: 2 }]
                }} options={{ ...commonChartOptions, scales: { x: { display: false }, y: { display: false } } }} />
              </div>
              <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.primary }} className="flex items-center gap-1">
                <TrendingDown size={14} /> 12% vs last month
              </div>
            </div>

            {/* Card 2 */}
            <div style={cardStyle}>
              <div style={{ fontFamily: 'Inter', fontSize: '14px', color: colors.muted, marginBottom: '8px' }}>Daily Average</div>
              <div style={{ fontFamily: 'Syne', fontSize: '40px', fontWeight: 'bold', color: colors.text, marginBottom: '4px' }}>{dailyAverage.toFixed(2)} <span style={{ fontSize: '16px', color: colors.muted }}>kg/day</span></div>
              <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.muted, marginBottom: '24px' }}>vs. Target: 5.00 kg/day</div>
              
              <div className="relative h-4 bg-black/50 rounded-full overflow-hidden mb-2">
                <div className="absolute top-0 left-0 h-full bg-[#00ff88]" style={{ width: `${Math.min((dailyAverage / 15) * 100, 100)}%` }}></div>
                <div className="absolute top-0 left-[33%] h-full w-1 bg-white/50 z-10"></div>
                <div className="absolute top-0 left-[66%] h-full w-1 bg-amber-500/50 z-10"></div>
              </div>
              <div className="flex justify-between text-[10px] text-gray-400 font-medium">
                <span style={{ width: '33%' }}>You</span>
                <span style={{ width: '33%', textAlign: 'center' }}>Target (5kg)</span>
                <span style={{ width: '33%', textAlign: 'right' }}>Global (10kg)</span>
              </div>
            </div>

            {/* Card 3 */}
            <div style={cardStyle} className="flex flex-col">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-[#00ff88]/20 flex items-center justify-center">
                  {getCategoryIcon(bestCategory.name)}
                </div>
                <div>
                  <div style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.text }}>{bestCategory.name}</div>
                  <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.muted }}>Lowest carbon impact</div>
                </div>
              </div>
              <div className="flex-1 flex items-center justify-center relative">
                 <div className="w-24 h-24">
                   <Doughnut data={{
                     labels: ['Best', 'Other'],
                     datasets: [{ data: [bestCategory.value, totalCarbonThisMonth - bestCategory.value], backgroundColor: [colors.primary, 'rgba(255,255,255,0.05)'], borderWidth: 0, cutout: '75%' }]
                   }} options={{ ...commonChartOptions, cutout: '75%' }} />
                 </div>
                 <div className="absolute inset-0 flex items-center justify-center">
                   <span style={{ fontFamily: 'Inter', fontSize: '14px', fontWeight: 'bold', color: colors.text }}>
                     {totalCarbonThisMonth > 0 ? Math.round((bestCategory.value / totalCarbonThisMonth) * 100) : 0}%
                   </span>
                 </div>
              </div>
            </div>

            {/* Card 4 */}
            <div style={cardStyle} className="flex flex-col">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-[#ef4444]/20 flex items-center justify-center">
                  {getCategoryIcon(worstCategory.name)}
                </div>
                <div>
                  <div style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.text }}>{worstCategory.name}</div>
                  <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.danger }}>Highest carbon impact</div>
                </div>
              </div>
              <div className="mt-auto p-3 rounded-lg bg-black/30 border border-white/5">
                <div style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 600, color: colors.secondary, marginBottom: '4px' }}>AI TIP</div>
                <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.text, lineHeight: 1.4 }}>
                  Consider reducing {worstCategory.name.toLowerCase()} activities to significantly lower your footprint.
                </div>
              </div>
            </div>
          </div>
        </div>
        <PageFooter pageNum={1} />
      </div>

      {/* PAGE 2: CARBON BREAKDOWN DEEP DIVE */}
      <div className="pdf-page" style={pageStyle}>
        <PageHeader />
        <div className="p-6 space-y-6">
          {/* Section 1: Daily Carbon Timeline */}
          <div style={cardStyle}>
            <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '16px' }}>Daily Carbon Output — Last 30 Days</h3>
            <div className="h-[180px]">
              <Bar data={dailyTimelineData} options={{
                ...commonChartOptions,
                plugins: {
                  annotation: {
                    annotations: {
                      targetLine: { type: 'line', yMin: 5, yMax: 5, borderColor: colors.primary, borderDash: [5, 5], borderWidth: 1, label: { content: 'Target', display: true, position: 'end', backgroundColor: 'transparent', color: colors.primary, font: { size: 10 } } },
                      avgLine: { type: 'line', yMin: 10, yMax: 10, borderColor: colors.secondary, borderDash: [2, 2], borderWidth: 1, label: { content: 'Global Avg', display: true, position: 'end', backgroundColor: 'transparent', color: colors.secondary, font: { size: 10 } } }
                    }
                  }
                } as any // Ignoring type error for annotation plugin which might not be fully typed here
              }} />
            </div>
          </div>

          {/* Section 2: Category Breakdown */}
          <div className="grid grid-cols-2 gap-6">
            <div style={cardStyle} className="flex flex-col items-center">
              <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '16px', alignSelf: 'flex-start' }}>Carbon by Category</h3>
              <div className="w-[200px] h-[200px] relative mb-6">
                <Doughnut data={donutData} options={commonChartOptions} />
                <div className="absolute inset-0 flex items-center justify-center flex-col">
                  <span style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.muted }}>Total</span>
                  <span style={{ fontFamily: 'Syne', fontSize: '24px', fontWeight: 'bold', color: colors.text }}>{totalCarbonThisMonth.toFixed(0)}</span>
                </div>
              </div>
              <div className="w-full grid grid-cols-2 gap-2">
                {categoryData.map(c => (
                  <div key={c.name} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: categoryColors[c.name] || colors.primary }}></div>
                    <span style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.text }}>{c.name} ({Math.round((c.value/totalCarbonThisMonth)*100)}%)</span>
                  </div>
                ))}
              </div>
            </div>

            <div style={cardStyle}>
              <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '24px' }}>Category Breakdown</h3>
              <div className="space-y-5">
                {categoryData.sort((a,b) => b.value - a.value).map(c => (
                  <div key={c.name}>
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center gap-2">
                        {getCategoryIcon(c.name)}
                        <span style={{ fontFamily: 'Inter', fontSize: '13px', fontWeight: 500, color: colors.text }}>{c.name}</span>
                      </div>
                      <span style={{ fontFamily: 'Inter', fontSize: '13px', fontWeight: 600, color: colors.text }}>{c.value.toFixed(1)} kg</span>
                    </div>
                    <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${(c.value / totalCarbonThisMonth) * 100}%`, backgroundColor: categoryColors[c.name] || colors.primary }}></div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-4 border-t border-white/5" style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.muted }}>
                Your worst category ({worstCategory.name}) contributes {totalCarbonThisMonth > 0 ? Math.round((worstCategory.value / totalCarbonThisMonth) * 100) : 0}% of total emissions.
              </div>
            </div>
          </div>

          {/* Section 3: Weekly Trend */}
          <div style={cardStyle}>
            <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '16px' }}>Weekly Carbon Trend</h3>
            <div className="h-[180px]">
              <Line data={weeklyTrendData} options={commonChartOptions} />
            </div>
          </div>
        </div>
        <PageFooter pageNum={2} />
      </div>

      {/* PAGE 3: ACTIVITY LOG & STREAK ANALYSIS */}
      <div className="pdf-page" style={pageStyle}>
        <PageHeader />
        <div className="p-6 space-y-6">
          {/* Section 1: Top 10 Activities */}
          <div style={cardStyle}>
            <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '16px' }}>Your Highest Impact Activities This Month</h3>
            <div className="w-full">
              <div className="flex text-[11px] font-semibold text-gray-500 mb-2 px-2 uppercase tracking-wider">
                <div className="w-12">Rank</div>
                <div className="flex-1">Activity</div>
                <div className="w-24">Category</div>
                <div className="w-20 text-right">Carbon</div>
                <div className="w-24 text-right">Date</div>
                <div className="w-32 ml-4">Impact</div>
              </div>
              {topActivities.slice(0, 10).map((act, i) => (
                <div key={i} className="flex items-center py-3 px-2 rounded-lg mb-1" style={{ backgroundColor: i % 2 === 0 ? 'rgba(0,0,0,0.2)' : 'transparent' }}>
                  <div className="w-12">
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold" style={{ backgroundColor: i === 0 ? colors.danger : i === 1 ? '#ea580c' : i === 2 ? colors.secondary : 'rgba(255,255,255,0.1)', color: i < 3 ? '#000' : '#fff' }}>
                      {i + 1}
                    </div>
                  </div>
                  <div className="flex-1" style={{ fontFamily: 'Inter', fontSize: '13px', color: colors.text, fontWeight: 500 }}>{act.activity_type}</div>
                  <div className="w-24">
                    <span className="px-2 py-1 rounded text-[10px] font-medium" style={{ backgroundColor: `${categoryColors[act.category] || colors.primary}20`, color: categoryColors[act.category] || colors.primary }}>
                      {act.category}
                    </span>
                  </div>
                  <div className="w-20 text-right" style={{ fontFamily: 'Inter', fontSize: '13px', color: colors.text, fontWeight: 600 }}>{act.carbon_kg.toFixed(1)} kg</div>
                  <div className="w-24 text-right" style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.muted }}>{new Date(act.logged_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</div>
                  <div className="w-32 ml-4 flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-black/50 rounded-full overflow-hidden">
                      <div className="h-full bg-red-500 rounded-full" style={{ width: `${Math.min((act.carbon_kg / 20) * 100, 100)}%` }}></div>
                    </div>
                    {i < 3 && <Flame size={14} className="text-orange-500" />}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 2: Streak Calendar (Simplified visualization for PDF) */}
          <div style={cardStyle}>
            <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '16px' }}>Green Day Streak Calendar</h3>
            <div className="flex gap-1 flex-wrap mb-4">
              {/* Generate 60 mock squares for visualization */}
              {Array.from({ length: 60 }).map((_, i) => {
                const val = Math.random() * 10;
                let bg = '#1a2f1a';
                if (val > 8) bg = '#7f1d1d';
                else if (val > 5) bg = '#f59e0b';
                else if (val > 3) bg = '#86efac';
                else if (val > 0) bg = '#00ff88';
                return <div key={i} className="w-4 h-4 rounded-sm" style={{ backgroundColor: bg }}></div>;
              })}
            </div>
            <div className="flex items-center gap-4 text-[11px] text-gray-400 mb-4">
              <span>Less</span>
              <div className="flex gap-1">
                <div className="w-3 h-3 rounded-sm bg-[#1a2f1a]"></div>
                <div className="w-3 h-3 rounded-sm bg-[#00ff88]"></div>
                <div className="w-3 h-3 rounded-sm bg-[#86efac]"></div>
                <div className="w-3 h-3 rounded-sm bg-[#f59e0b]"></div>
                <div className="w-3 h-3 rounded-sm bg-[#7f1d1d]"></div>
              </div>
              <span>More</span>
            </div>
            <div className="flex gap-8 border-t border-white/5 pt-4">
              <div><span style={{ color: colors.muted, fontSize: '12px' }}>Current Streak:</span> <strong style={{ color: colors.text }}>{streak} days 🔥</strong></div>
              <div><span style={{ color: colors.muted, fontSize: '12px' }}>Longest Streak:</span> <strong style={{ color: colors.text }}>{user?.longest_streak || 0} days</strong></div>
              <div><span style={{ color: colors.muted, fontSize: '12px' }}>Green Days:</span> <strong style={{ color: colors.text }}>{greenDays}/30</strong></div>
            </div>
          </div>

          {/* Section 3: Eco Behavior Score Card */}
          <div className="grid grid-cols-3 gap-4">
            {['Transport', 'Food', 'Energy'].map((cat, i) => (
              <div key={cat} style={cardStyle} className="flex flex-col items-center text-center">
                <div style={{ fontFamily: 'Inter', fontSize: '14px', fontWeight: 600, color: colors.text, marginBottom: '12px' }}>{cat} Habits</div>
                <div className="relative w-20 h-20 mb-4">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle cx="40" cy="40" r="36" stroke="rgba(255,255,255,0.1)" strokeWidth="6" fill="none" />
                    <circle cx="40" cy="40" r="36" stroke={colors.primary} strokeWidth="6" fill="none" strokeDasharray="226" strokeDashoffset={226 - (226 * 0.8)} strokeLinecap="round" />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center" style={{ fontFamily: 'Syne', fontSize: '20px', fontWeight: 'bold', color: colors.text }}>80</div>
                </div>
                <div style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.muted }}>
                  {i === 0 ? "80% of trips were low-carbon" : i === 1 ? "15 plant meals this month" : "Avg 1.2 kg/day from energy"}
                </div>
              </div>
            ))}
          </div>
        </div>
        <PageFooter pageNum={3} />
      </div>

      {/* PAGE 4: AI INSIGHTS & ACTION PLAN */}
      <div className="pdf-page" style={pageStyle}>
        <PageHeader />
        <div className="p-6 space-y-6">
          {/* Section 1: AI Carbon Projection */}
          <div style={cardStyle}>
            <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '16px' }}>AI-Predicted Monthly Carbon Output</h3>
            <div className="h-[160px] relative">
              <Line data={projectionData} options={commonChartOptions} />
              <div className="absolute top-4 right-4 bg-black/50 border border-amber-500/30 p-3 rounded-lg backdrop-blur-sm">
                <div style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.muted, marginBottom: '4px' }}>Projected Total</div>
                <div style={{ fontFamily: 'Syne', fontSize: '24px', fontWeight: 'bold', color: colors.secondary }}>{aiProjection?.predicted_kg || 0} kg</div>
              </div>
            </div>
          </div>

          {/* Section 2: AI Action Plan */}
          <div style={cardStyle}>
            <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '4px' }}>Your AI-Generated 30-Day Improvement Plan</h3>
            <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.muted, marginBottom: '16px' }}>Based on your activity data — Generated by Gemini AI</div>
            <div className="space-y-3">
              {aiActionPlan.map((action, i) => (
                <div key={i} className="flex gap-4 p-3 rounded-xl bg-black/20 border border-white/5">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-black flex-shrink-0" style={{ backgroundColor: action.difficulty === 1 ? colors.primary : action.difficulty === 5 ? colors.danger : colors.secondary }}>
                    {i + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                      <div style={{ fontFamily: 'Inter', fontSize: '14px', fontWeight: 600, color: colors.text }}>{action.title}</div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-[#00ff88]/10 text-[#00ff88]">
                        💚 Saves ~{action.estimated_saving_kg} kg/mo
                      </span>
                    </div>
                    <div style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.muted, lineHeight: 1.4 }}>{action.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 3: Equivalencies */}
          <div style={cardStyle}>
            <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '16px' }}>What Your Carbon Footprint Equals</h3>
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-black/20 p-4 rounded-xl text-center border border-white/5">
                <div className="flex justify-center mb-2"><Leaf size={24} color={colors.primary} /></div>
                <div style={{ fontFamily: 'Syne', fontSize: '24px', fontWeight: 'bold', color: colors.text }}>{(totalCarbonThisMonth / 21).toFixed(1)}</div>
                <div style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.muted }}>Trees needed to offset</div>
              </div>
              <div className="bg-black/20 p-4 rounded-xl text-center border border-white/5">
                <div className="flex justify-center mb-2"><Plane size={24} color={colors.secondary} /></div>
                <div style={{ fontFamily: 'Syne', fontSize: '24px', fontWeight: 'bold', color: colors.text }}>{((totalCarbonThisMonth / 0.255) / 800).toFixed(1)}</div>
                <div style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.muted }}>Hours of flying</div>
              </div>
              <div className="bg-black/20 p-4 rounded-xl text-center border border-white/5">
                <div className="flex justify-center mb-2"><Car size={24} color="#3b82f6" /></div>
                <div style={{ fontFamily: 'Syne', fontSize: '24px', fontWeight: 'bold', color: colors.text }}>{(totalCarbonThisMonth / 0.21).toFixed(0)}</div>
                <div style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.muted }}>km driven in a car</div>
              </div>
              <div className="bg-black/20 p-4 rounded-xl text-center border border-white/5">
                <div className="flex justify-center mb-2"><Battery size={24} color="#a855f7" /></div>
                <div style={{ fontFamily: 'Syne', fontSize: '24px', fontWeight: 'bold', color: colors.text }}>{(totalCarbonThisMonth / 0.005).toLocaleString(undefined, {maximumFractionDigits:0})}</div>
                <div style={{ fontFamily: 'Inter', fontSize: '11px', color: colors.muted }}>Phone charges</div>
              </div>
            </div>
          </div>

          {/* Section 4: Badges */}
          <div style={cardStyle}>
            <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 600, color: colors.primary, marginBottom: '16px' }}>Achievements Unlocked</h3>
            <div className="grid grid-cols-3 gap-4">
              {badges.slice(0, 3).map((badge, i) => (
                <div key={i} className="flex items-center gap-3 bg-black/20 p-3 rounded-xl border border-white/5">
                  <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center">
                    <Trophy size={20} className="text-amber-500" />
                  </div>
                  <div>
                    <div style={{ fontFamily: 'Inter', fontSize: '13px', fontWeight: 600, color: colors.text }}>{badge.name || 'Eco Starter'}</div>
                    <div style={{ fontFamily: 'Inter', fontSize: '10px', color: colors.muted }}>{new Date(badge.earned_at || Date.now()).toLocaleDateString()}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Back Cover Footer */}
        <div className="absolute bottom-0 w-full bg-[#051009] p-8 text-center border-t border-[#00ff88]/20">
          <div style={{ fontFamily: 'Syne', fontSize: '20px', color: colors.primary, fontStyle: 'italic', marginBottom: '16px' }}>
            "Keep making green choices. Every kg saved matters."
          </div>
          <div className="inline-block px-6 py-3 rounded-full border border-[#00ff88]/30 bg-[#00ff88]/5 mb-6">
            <span style={{ fontFamily: 'Inter', fontSize: '14px', color: colors.text }}>I pledge to reduce by 10 kg next month — <strong>{user?.display_name}</strong></span>
          </div>
          <div style={{ fontFamily: 'Inter', fontSize: '12px', color: colors.muted }}>
            GreenScore Eco Tracker • Report generated on {new Date().toLocaleDateString()}
          </div>
        </div>
      </div>
    </div>
  );
};
